# Plano de Testes de Email — Yalt CRM (executável + estado real)

> Auditoria CTO Operacional · 2026-06-25 · domínio remetente: **yalt.co**

## TL;DR (veredito)

A **fundação de entregabilidade** do `yalt.co` é **sólida para envio via Gmail/Google Workspace** (SPF ✓, DKIM ✓, DMARC publicado), com 2 melhorias recomendadas.

**Mas o plano de testes assume um ESP com tracking nativo** (opens/clicks, webhooks de bounce/unsubscribe, endpoint `/api/v1/emails/send`) que a Yalt **não tem hoje** no caminho de produção:
- Produção atual = **rascunhos Gmail** gerados por IA no n8n + **envio manual** (sem tracking de opens/clicks/bounce).
- O **Gmail OAuth está partido** (YAL-5) → neste momento nem os rascunhos estão a ser criados.
- O endpoint de email do CRM (`/api/v1/emails/send`) **não está confirmado** — a API documentada do CRM é CRUD de leads.

➡️ Conclusão: **SPF/DKIM/DMARC — feito agora**. A maioria dos restantes testes (tracking, bounce webhooks, A/B por open-rate, monitorização 24-72h) **não é executável** até existir (a) Gmail religado **e** (b) uma camada de ESP/tracking.

---

## 1. Verificação técnica (Etapa 1) — ✅ EXECUTADO

Resultados DNS reais (consultados via DNS-over-HTTPS, 2026-06-25):

| Registo | Valor | Estado |
|---|---|---|
| **SPF** | `v=spf1 include:_spf.google.com include:spf.ipzmarketing.com ~all` | ⚠️ OK c/ ressalvas |
| **DKIM** (`google._domainkey`) | `v=DKIM1; k=rsa; p=MIIBIjANB…` (chave válida) | ✅ |
| **DMARC** (`_dmarc.yalt.co`) | `v=DMARC1; p=none; rua=mailto:dmarc-reports@yalt.co` | ⚠️ não força |
| **MX** | `aspmx.l.google.com` (Google Workspace) | ✅ |

**Análise:**
- ✅ Mail enviado **pelo Gmail/@yalt.co** fica **SPF + DKIM + DMARC alinhado** → boa colocação em inbox.
- ⚠️ **SPF `~all` (softfail)** — recomendado passar a `-all` (hardfail) depois de confirmar todos os remetentes legítimos.
- ⚠️ **SendGrid não está no SPF.** A credencial "Sengrid email" (SMTP) no n8n, **se enviar de @yalt.co, falha SPF** → não usar para envio com esse From sem adicionar `include:sendgrid.net`.
- ⚠️ **IPzMarketing (E-goi)** está autorizado no SPF (há/houve um ESP). **Verificar o DKIM da IPzMarketing** (selector próprio) se for usada para envios.
- 🔴 **DMARC `p=none`** = só monitorização, **não bloqueia spoofing** nem ganha o boost de reputação do enforcement.

---

## 2. Arquitetura real vs. o que o plano assume

| Capacidade do plano | Existe na Yalt hoje? | Nota |
|---|---|---|
| Endpoint CRM `/api/v1/emails/send` | ❓ **Não confirmado** | API conhecida do CRM = CRUD de leads (`portal.sales-crm.yalt.co/functions/v1/v1/api/leads`). Verificar com Madine (YAL-8) |
| Envio real de email | ◑ **Gmail drafts** (n8n → revisão/envio manual) | Gmail OAuth **partido** (YAL-5) |
| Tracking opens/clicks | 🔴 **Não** | Rascunhos Gmail não têm tracking. Precisa ESP ou pixel/UTM próprio |
| Webhooks bounce/unsubscribe | 🔴 **Não** | Precisa ESP (IPzMarketing/SendGrid) |
| Sync de interações → CRM | ◑ **Parcial** | Workflow n8n "CRM Status Sync" existe mas **inativo** (sem credencial) |

---

## 3. O que é executável HOJE vs. BLOQUEADO

**Executável agora (autónomo):**
- ✅ **SPF/DKIM/DMARC** — feito (secção 1).
- ◑ **Personalização (TC1/TC2)** — a Yalt **não usa templates `{{var}}`**; usa **geração por IA por lead** (agente "Redigir Outreach"), com instrução explícita anti-placeholder ("Nunca usar [Nome]/[Empresa]"). Testável correndo o Pilot num lead seed (gera `email_subject`/`email_body`). Validado em sessões anteriores.

**Bloqueado (precisa de pessoa ou de build):**
- 🔴 **Envio seed 1:1 e lote** → precisa Gmail religado (YAL-5) ou um ESP configurado.
- 🔴 **Tracking opens/clicks + UTM no CRM** → não existe camada de tracking.
- 🔴 **Webhooks de bounce/unsubscribe + opt-out no CRM** → precisa ESP + endpoint webhook (proteger com HMAC).
- 🔴 **A/B de assunto, monitorização 24-72h** → precisa envio real + tracking.
- 🔴 **Logs de eventos (open/click/reply/bounce/unsub) no contacto** → precisa API de email do CRM (YAL-8) + sync.

---

## 4. Test cases adaptados à realidade Yalt

| TC | Plano original | Adaptação Yalt | Estado |
|---|---|---|---|
| TC1 | "Olá João," + UTM | IA gera assunto/corpo com `chain_name`/setor reais; validar ausência de placeholders | ◑ lógica validada |
| TC2 | fallback nome vazio | prompt já proíbe placeholders; Yalt usa `chain_name` (empresa), não `first_name` | ✅ coberto por prompt |
| TC3 | bounce → evento CRM | **não testável** sem ESP/webhook | 🔴 bloqueado |
| TC4 | unsubscribe → opt-out CRM | **não existe** link/fluxo de unsubscribe nos rascunhos atuais | 🔴 gap a corrigir |

---

## 5. Recomendações priorizadas (CTO)

- **P0 — Religar Gmail OAuth (YAL-5).** Desbloqueia o único caminho de envio real existente.
- **P0 — Endurecer DNS.** DMARC `p=none` → `p=quarantine` (depois `p=reject`) após rever os relatórios `rua`; SPF `~all` → `-all`.
- **P1 — Decidir a camada de envio em escala.** Gmail é bom para **1:1 de alto valor** (Classe A), mas **NÃO** para cold outreach a 307K (risco de bloqueio da conta Google). Para escala → **ESP dedicado** (IPzMarketing já no SPF, ou SendGrid) com **aquecimento de domínio/IP**, DKIM próprio e tracking.
- **P1 — Conformidade legal antes de massa.** Adicionar `List-Unsubscribe` + fluxo de opt-out (CAN-SPAM/GDPR) — atualmente inexistente.
- **P2 — Tracking + sync.** UTM nos links; opens/clicks via ESP; sync de eventos para o CRM (depende de YAL-8).

---

## 6. Checklist pré-produção (estado real)

- [x] SPF verificado (`google` + `ipzmarketing`, `~all`)
- [~] DKIM (`google` ✓; ESP por verificar)
- [ ] DMARC a forçar (atual `p=none`)
- [ ] Template aprovado desktop/mobile (atual: HTML gerado por IA, sem teste Litmus/Email-on-Acid)
- [ ] Links com UTM (não implementado)
- [ ] Seed list testada (não existe)
- [ ] Webhooks bounce/unsub (não existe — precisa ESP)
- [ ] Unsubscribe funcional (não existe)
- [ ] Plano de rollback (parcial: Pilot/Orquestrador são desativáveis no n8n)
- [ ] **Gmail OAuth religado (YAL-5) ← BLOQUEIO upstream**

---

## Segurança
- **Tokens nunca no chat nem em repositórios.** A chave do CRM colada anteriormente no chat deve ser **revogada**.
- Endpoints de webhook (quando existirem): proteger com **assinatura HMAC**.
- Staging com domínio/remetente próprios antes de produção.
