## Imported Claude Cowork project instructions

Workspace comercial da Yalt para qualificação de leads, preparação de reuniões, follow-ups, propostas e gestão de oportunidades.
